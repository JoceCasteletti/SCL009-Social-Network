export const logoutMessage = () => {
    console.log("bye")
    }
    
    logoutMessage();